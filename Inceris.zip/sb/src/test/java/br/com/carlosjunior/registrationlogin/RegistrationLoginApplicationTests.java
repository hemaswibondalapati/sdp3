package br.com.carlosjunior.registrationlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
