package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.carlosjunior.registrationlogin.entities.Student;

public interface StudentRepository extends JpaRepository<Student,Long>{

}
