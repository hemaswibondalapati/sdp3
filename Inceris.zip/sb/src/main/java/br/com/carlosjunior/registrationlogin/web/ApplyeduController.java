package br.com.carlosjunior.registrationlogin.web;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.carlosjunior.registrationlogin.entities.Applyedu;
import br.com.carlosjunior.registrationlogin.services.ApplyeduInterface;
 
@Controller
public class ApplyeduController
{
	
	private ApplyeduInterface applyeduService;
	
	public ApplyeduController(ApplyeduInterface applyeduService) {
		super();
		this.applyeduService= applyeduService;
	}
	
	@GetMapping("/apply")
	public String listeducates(Model model)
	{
		model.addAttribute("applyedu", applyeduService.getAllapllies());
		return "apply";
		
	}
 
	
	 
	@PostMapping("/applyedu")
	public String saverecord(@ModelAttribute("applyedu") Applyedu std)
	{
		applyeduService.saveStudent(std);
		return "redirect:/thankyou";
	}
	
	
	
	
	@GetMapping("/apply/new")
	public String createstudenform(Model model)	
	{
		 
		Applyedu ed=new Applyedu();
		model.addAttribute("applyedu",ed);
		return "createapply";
 	
	}

	@GetMapping("/thankyou")
	public String thanks(Model model)	
	{
 		return "thankyou";
 	
	}
	@GetMapping("/choice")
	public String choice(Model model)	
	{
 		return "main";
 	
	}
	
	@GetMapping("/admin")
	public String admin(Model model)	
	{
 		return "admin";
 	
	}
	
	
	
	@GetMapping("/applyedu/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("applyedu", applyeduService.getStudentById(id));
		return "editapply";
	}

	@PostMapping("/applyedu/{id}")
	public String updateStudent(@PathVariable Long id,
			@ModelAttribute("applyedu") Applyedu student,
			Model model) {
		
		// get student from database by id
		Applyedu existingStudent = applyeduService.getStudentById(id);
		existingStudent.setId(id);
		existingStudent.setStatus(student.getStatus());
	 	
		// save updated student object
		applyeduService.updateStudent(existingStudent);
		return "redirect:/apply";		
	}
	
	// handler method to handle delete student request
	
	@GetMapping("/applyedu/{id}")
	public String deleteStudent(@PathVariable Long id) {
		applyeduService.deleteStudentById(id);
		return "redirect:/apply";
	}


}
