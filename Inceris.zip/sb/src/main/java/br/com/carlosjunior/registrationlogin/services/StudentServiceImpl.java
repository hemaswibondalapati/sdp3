package br.com.carlosjunior.registrationlogin.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.carlosjunior.registrationlogin.entities.Student;
import br.com.carlosjunior.registrationlogin.repositories.StudentRepository;
import br.com.carlosjunior.registrationlogin.services.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	private StudentRepository studentRepository;
 	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

 
	@Override
	public List<Student> getAllStudents() {
		
		return studentRepository.findAll();
	}

 

	@Override
	public Student saveStudent(Student std) {
		 return studentRepository.save(std);
	}
}
