package br.com.carlosjunior.registrationlogin.services;

import java.util.List;

import br.com.carlosjunior.registrationlogin.entities.Job;
public interface JobService
{
	List<Job>getAlljobs();

	Job saveJobs(Job job);
	
	Job getjobById(Long id);
	
	Job updatejob(Job job);
}
