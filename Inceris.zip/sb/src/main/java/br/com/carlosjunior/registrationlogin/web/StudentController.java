package br.com.carlosjunior.registrationlogin.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.carlosjunior.registrationlogin.entities.Student;
import br.com.carlosjunior.registrationlogin.services.StudentService;

@Controller
public class StudentController {

	
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}
	//handler methods
	
	@GetMapping("/students")
	public String liststudents(Model model)
	{
		model.addAttribute("students", studentService.getAllStudents());
		return "students";
		
	}
	@GetMapping("/students/new")
	public String createstudenform(Model model)	
	{
		Student std=new Student();
		model.addAttribute("student",std);
		return "createform";
 	
	}
	@PostMapping("/students")
	public String saverecord(@ModelAttribute("student") Student std)
	{
		studentService.saveStudent(std);
		return "redirect:/admin";
	}
	
	@GetMapping("/category")
	public String showcateory(Model model)	
	{
		 
		return "category";
 	
	}
	
	@GetMapping("/admintry")
	public String admintry(Model model)	
	{
		 
		return "admintry";
 	
	}
	
	
	
	
}
