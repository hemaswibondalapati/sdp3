package br.com.carlosjunior.registrationlogin.services;
import java.util.*;

import br.com.carlosjunior.registrationlogin.entities.Applyedu;
public interface ApplyeduInterface 
{
	List<Applyedu>getAllapllies();

	Applyedu saveStudent(Applyedu std);
	
Applyedu getStudentById(Long id);
	
	Applyedu updateStudent(Applyedu student);
	
	void deleteStudentById(Long id);
}
