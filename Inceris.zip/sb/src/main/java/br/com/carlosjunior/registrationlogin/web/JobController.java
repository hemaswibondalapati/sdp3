package br.com.carlosjunior.registrationlogin.web;



import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.carlosjunior.registrationlogin.entities.Job;
import br.com.carlosjunior.registrationlogin.services.JobService;
 

@Controller
public class JobController
{
	
	private JobService jobService;
	
	public JobController(JobService jobService) {
		super();
		this.jobService = jobService;
	}
	
	@GetMapping("/jobs")
	public String listjobs(Model model)
	{
		model.addAttribute("jobs", jobService.getAlljobs());
		return "jobs";
		
	}
	
  
 
	
	 
	@PostMapping("/jobb")
	public String saverecord(@ModelAttribute("jobs") Job job)
	{
		jobService.saveJobs(job);
		return "redirect:/thankyou";
	}
	
	
	
	
	@GetMapping("/job/new")
	public String createstudenform(Model model)	
	{
		 
		Job ed=new Job();
		model.addAttribute("jobs",ed);
		return "applyjob";
 	
	}

	@GetMapping("/hire")
	public String hire(Model model)	
	{
 		return "hire";
 	
	}
	
	
	
	@GetMapping("/jobs/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) {
		model.addAttribute("jobs", jobService.getjobById(id));
		return "editjobs";
	}

	@PostMapping("/jobs/{id}")
	public String updateStudent(@PathVariable Long id,
			@ModelAttribute("jobs") Job job,
			Model model) {
		
		// get student from database by id
		Job existingStudent = jobService.getjobById(id);
		existingStudent.setId(id);
		 
		existingStudent.setStatus(job.getStatus());
		
		// save updated student object
		jobService.updatejob(existingStudent);
		return "redirect:/jobs";		
	}
	

}
