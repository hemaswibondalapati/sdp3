package br.com.carlosjunior.registrationlogin.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hires")
public class Hire {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "cname")
	private String cname;


	@Column(name="description")
	private String description;

	 
	@Column(name="status")
	private String status="Pending";
	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Column(name = "duration")
	private String duration;

	@Column(name = "salary")
	private String salary;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public Hire(Long id, String cname, String status,String description, String duration, String salary) {
		super();
		this.id = id;
		this.cname = cname;
		this.status="Pending";
		this.description = description;
		this.duration = duration;
		this.salary = salary;
	}
	
	public Hire()
	{
		
	}

	 
}
