package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.carlosjunior.registrationlogin.entities.Applyedu;

public interface ApplyeduRepository extends JpaRepository<Applyedu,Long>{

}
