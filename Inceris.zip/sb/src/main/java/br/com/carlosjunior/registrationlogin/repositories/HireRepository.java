package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.carlosjunior.registrationlogin.entities.Hire;

public interface HireRepository extends JpaRepository<Hire,Long>{

}
