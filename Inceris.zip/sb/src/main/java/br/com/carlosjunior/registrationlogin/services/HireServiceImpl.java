package br.com.carlosjunior.registrationlogin.services;

import java.util.List;

import org.springframework.stereotype.Service;

import br.com.carlosjunior.registrationlogin.entities.Hire;
import br.com.carlosjunior.registrationlogin.repositories.HireRepository;

@Service
public class HireServiceImpl implements HireService{

	
	private HireRepository hirerepository;
	
	
	public HireServiceImpl(HireRepository hirerepository) {
		super();
		this.hirerepository = hirerepository;
	}

	@Override
	public List<Hire> gethires() {
		// TODO Auto-generated method stub
		return hirerepository.findAll();
	}

	@Override
	public Hire savehires(Hire hire) {
		// TODO Auto-generated method stub
		return hirerepository.save(hire);
	}

	@Override
	public Hire getStudentById(Long id) {
		// TODO Auto-generated method stub
		return hirerepository.findById(id).get();
	}

	@Override
	public Hire updateStudent(Hire hire) {
		// TODO Auto-generated method stub
		return hirerepository.save(hire);
	}

	@Override
	public void deleteStudentById(Long id) {
		// TODO Auto-generated method stub
		hirerepository.deleteById(id);
		
	}

}
