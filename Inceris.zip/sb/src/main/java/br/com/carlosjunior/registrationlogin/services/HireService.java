package br.com.carlosjunior.registrationlogin.services;

import java.util.List;

import br.com.carlosjunior.registrationlogin.entities.Hire;

public interface HireService
{
	List<Hire>gethires();
	Hire savehires(Hire hire);

	Hire getStudentById(Long id);
	
	Hire updateStudent(Hire hire);
	
	void deleteStudentById(Long id);
}
