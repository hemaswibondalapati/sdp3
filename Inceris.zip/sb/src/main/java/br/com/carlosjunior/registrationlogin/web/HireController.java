package br.com.carlosjunior.registrationlogin.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import br.com.carlosjunior.registrationlogin.entities.Hire;
import br.com.carlosjunior.registrationlogin.services.HireService;

@Controller
public class HireController {

	
	private HireService hireService;

	public HireController(HireService hireService) {
		super();
		this.hireService = hireService;
	}
	//handler methods
	
	@GetMapping("/hired")
	public String liststudents(Model model)
	{
		model.addAttribute("hires", hireService.gethires());
		return "hire";
		
	}
	@GetMapping("/hire/new")
	public String createstudenform(Model model)	
	{
		Hire std=new Hire();
		model.addAttribute("hires",std);
		return "applyhire";
 	
	}
	@PostMapping("/hiree")
	public String saverecord(@ModelAttribute("hires") Hire std)
	{
		hireService.savehires(std);
		return "redirect:/admin";
	}
	

	 
	
	
}
